# class SalesManager:                                                 # класс считает финансовые отчеты
#     def __init__(self, data_manager):                               # получает DataManager, чтобы работать с продажами
#         self.data_manager = data_manager
#
#     def total_revenue(self):                                        # суммирует все продажи
#         return sum(sale["sale_price"] for sale in self.data_manager.data["sales"])

import json
from datetime import datetime
from collections import Counter

class SalesManager:
    def __init__(self, data_manager):
        self.data_manager = data_manager

    def total_revenue(self, start_date=None, end_date=None):
        sales = self.filter_sales_by_date(start_date, end_date)
        return sum(sale["sale_price"] for sale in sales)

    def filter_sales_by_date(self, start_date=None, end_date=None):
        sales = self.data_manager.data["sales"]
        if start_date:
            sales = [sale for sale in sales if sale["date"] >= start_date]
        if end_date:
            sales = [sale for sale in sales if sale["date"] <= end_date]
        return sales

    def sales_by_date(self, date):
        return [sale for sale in self.data_manager.data["sales"] if sale["date"].startswith(date)]

    def sales_by_period(self, start_date, end_date):
        return self.filter_sales_by_date(start_date, end_date)

    def sales_by_employee(self, employee_name):
        return [sale for sale in self.data_manager.data["sales"] if sale["employee"] == employee_name]

    def best_selling_book(self, start_date=None, end_date=None):
        sales = self.filter_sales_by_date(start_date, end_date)
        book_counts = Counter(sale["book"] for sale in sales)
        return book_counts.most_common(1)[0] if book_counts else None

    def best_selling_employee(self, start_date=None, end_date=None):
        sales = self.filter_sales_by_date(start_date, end_date)
        employee_counts = Counter(sale["employee"] for sale in sales)
        return employee_counts.most_common(1)[0] if employee_counts else None

    def best_selling_author(self, start_date=None, end_date=None):
        sales = self.filter_sales_by_date(start_date, end_date)
        books = {book["title"]: book["author"] for book in self.data_manager.data["books"]}
        author_counts = Counter(books[sale["book"]] for sale in sales if sale["book"] in books)
        return author_counts.most_common(1)[0] if author_counts else None

    def best_selling_genre(self, start_date=None, end_date=None):
        sales = self.filter_sales_by_date(start_date, end_date)
        books = {book["title"]: book["genre"] for book in self.data_manager.data["books"]}
        genre_counts = Counter(books[sale["book"]] for sale in sales if sale["book"] in books)
        return genre_counts.most_common(1)[0] if genre_counts else None