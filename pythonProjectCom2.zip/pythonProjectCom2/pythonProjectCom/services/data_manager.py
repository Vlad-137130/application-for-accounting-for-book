import json                                             # Импортируем json, чтобы сохранять и загружать данные.

class DataManager:#
    def __init__(self, filename="data.json"):
        self.filename = filename                                    # имя файла, в котором хранятся данные
        self.data = {"employees": [], "books": [], "sales": []}     # словарь с тремя списками: сотрудники, книги, продажи
        self.load_data()                                            # загружаем данные из файла

    def save_data(self):                                            # записывает self.data в JSON-файл
        with open(self.filename, "w") as f:
            json.dump(self.data, f, indent=4)

    def load_data(self):                                # загружает данные из файла. Если файла нет — создает пустую базу
        try:
            with open(self.filename, "r") as f:
                self.data = json.load(f)
        except FileNotFoundError:
            self.data = {"employees": [], "books": [], "sales": []}

    def add_employee(self, employee):                               # добавляет сотрудника в список и сохраняет данные
        self.data["employees"].append(employee.to_dict())
        self.save_data()

    def add_book(self, book):                               # добавляет книгу в список и сохраняет данные
        self.data["books"].append(book.to_dict())
        self.save_data()

    def add_sale(self, sale):                               # добавляет информацию о продаже в список и сохраняет данные
        self.data["sales"].append(sale.to_dict())
        self.save_data()