from models.employee import Employee
from models.book import Book
from models.sale import Sale
from services.data_manager import DataManager
from services.sales_manager import SalesManager


def show_main_menu():                                           # Выводит главное меню и ждет ввода от пользователя
    print("\nГлавное меню:")
    print("1. Работа с сотрудниками")
    print("2. Работа с книгами")
    print("3. Работа с продажами")
    print("4. Отчеты")
    print("5. Выход")
    return input("Выберите действие: ")


def manage_employees(dm):                                       # Подменю работы с сотрудниками
    while True:                 # Запускается цикл while True, чтобы пользователь мог выполнять несколько действий подряд
        print("\nМеню сотрудников:")
        print("1. Добавить сотрудника")
        print("2. Показать всех сотрудников")
        print("3. Вернуться в главное меню")
        choice = input("Выберите действие: ")

        if choice == "1":                                               # Запрашиваем у пользователя данные
            full_name = input("Введите ФИО: ")
            position = input("Введите должность: ")
            phone = input("Введите телефон: ")
            email = input("Введите Email: ")
            emp = Employee(full_name, position, phone, email)           # Создаем объект Employee
            dm.add_employee(emp)                                        # Добавляем его в DataManager
            print("Сотрудник добавлен!")
        elif choice == "2":                                             # Выводим всех сотрудников
            for emp in dm.data["employees"]:
                print(emp)
        elif choice == "3":                                             # Выход из подменю сотрудников
            break


def manage_books(dm):                                                   # Подменю работы с книгами
    while True:
        print("\nМеню книг:")
        print("1. Добавить книгу")
        print("2. Показать все книги")
        print("3. Вернуться в главное меню")
        choice = input("Выберите действие: ")

        if choice == "1":
            title = input("Введите название книги: ")
            year = int(input("Введите год публикации: "))
            author = input("Введите автора: ")
            genre = input("Введите жанр: ")
            cost_price = float(input("Введите себестоимость: "))
            sale_price = float(input("Введите цену продажи: "))
            book = Book(title, year, author, genre, cost_price, sale_price)         # Создаем объект Book
            dm.add_book(book)                                                       # Добавляем его в DataManager
            print("Книга добавлена!")
        elif choice == "2":
            for book in dm.data["books"]:
                print(book)
        elif choice == "3":
            break


def manage_sales(dm):                                                   # Подменю работы с продажами
    while True:
        print("\nМеню продаж:")
        print("1. Добавить продажу")
        print("2. Показать все продажи")
        print("3. Вернуться в главное меню")
        choice = input("Выберите действие: ")

        if choice == "1":                                               # Если выбрано "Добавить продажу"
            employee_name = input("Введите имя сотрудника: ")           # Запрашиваем имя сотрудника и название книги
            book_title = input("Введите название книги: ")
            sale_price = float(input("Введите цену продажи: "))

            employee = next((e for e in dm.data["employees"] if e["full_name"] == employee_name), None) # Находим сотрудника в dm.data["employees"]
            book = next((b for b in dm.data["books"] if b["title"] == book_title), None)                # Находим книгу в dm.data["books"]

            if employee and book:                                                                       # Если нашли
                sale = Sale(Employee(**employee), Book(**book), sale_price)                             # создаем объект Sale и добавляем
                dm.add_sale(sale)
                print("Продажа добавлена!")
            else:
                print("Ошибка: сотрудник или книга не найдены!")
        elif choice == "2":
            for sale in dm.data["sales"]:
                print(sale)
        elif choice == "3":
            break


def main():                                                         # Главное управление программой
    dm = DataManager()                                              # Создаем объект DataManager, который загружает все данные из data.json
    sales_manager = SalesManager(dm)                                # Создаем объект SalesManager, который управляет отчетами

    while True:                                                     # Запускаем цикл главного меню
        choice = show_main_menu()
        if choice == "1":
            manage_employees(dm)
        elif choice == "2":
            manage_books(dm)
        elif choice == "3":
            manage_sales(dm)
        elif choice == "4":
            print(f"Общий доход: {sales_manager.total_revenue()} грн")
        elif choice == "5":
            print("Выход из программы.")
            break
        else:
            print("Ошибка ввода! Попробуйте снова.")


if __name__ == "__main__":
    main()