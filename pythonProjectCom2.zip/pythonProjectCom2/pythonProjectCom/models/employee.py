class Employee:         #   хранить информацию о сотруднике
    def __init__(self, full_name, position, phone, email):
        self.full_name = full_name                              # Полное имя сотрудника
        self.position = position                                # Должность
        self.phone = phone                                      # Телефон
        self.email = email                                      # Email

    def to_dict(self):                                # превращает объект Employee в словарь. чтобы сохранять его в JSON
        return self.__dict__

    @staticmethod
    def from_dict(data):                    # принимает словарь и создает из него объект Employee. Для загрузки из JSON
        return Employee(**data)