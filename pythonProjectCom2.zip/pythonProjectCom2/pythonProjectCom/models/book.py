class Book:                                                                 # класс описывает книгу
    def __init__(self, title, year, author, genre, cost_price, sale_price):
        self.title = title
        self.year = year
        self.author = author
        self.genre = genre
        self.cost_price = cost_price
        self.sale_price = sale_price

    def to_dict(self):                                      # превращает объект Book в словарь. чтобы сохранять его в JSON
        return self.__dict__

    @staticmethod
    def from_dict(data):                        # принимает словарь и создает из него объект Book. Для загрузки из JSON
        return Book(**data)