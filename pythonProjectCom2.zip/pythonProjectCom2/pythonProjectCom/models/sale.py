from datetime import datetime                       # Импортируем datetime, чтобы фиксировать дату продажи

class Sale:                                         # хранит информацию о продаже
    def __init__(self, employee, book, sale_price, date=None):
        self.employee = employee.full_name                                  # Продавец
        self.book = book.title                                              # Книга
        self.sale_price = sale_price                                        # Цена продажи
        self.date = date or datetime.now().strftime("%Y-%m-%d %H:%M:%S")    # если не передали, то используем текущую дату

    def to_dict(self):                                      # превращает объект Sale в словарь. чтобы сохранять его в JSON
        return self.__dict__

    @staticmethod
    def from_dict(data):                            # принимает словарь и создает из него объект Book. Для загрузки из JSON
        return Sale(Employee(data['employee'], '', '', ''), Book(data['book'], 0, '', '', 0, 0), data['sale_price'], data['date'])